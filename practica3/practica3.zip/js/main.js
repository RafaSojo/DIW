function comprobarModernizr(){
    alert(((Modernizr.canvas) ? 'si':'no') + " soporta canvas");
    alert(((Modernizr.svg) ? 'si':'no') + " soporta svg");
    alert(((Modernizr.smil) ? 'si':'no') + " soporta smil");
    alert(((Modernizr.touch) ? 'si':'no') + " soporta touch");
    
}
